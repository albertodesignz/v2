# React Bits Starter

A mobile-first React starter using [@DavidHDev/react-bits](https://www.reactbits.dev/) components:

- ProfileCard for user profile display
- CircularGallery to showcase “emotions” or mood icons

## Features

- ⚡ Fast Vite setup
- 📱 Mobile-first responsive design
- 🧩 Uses ProfileCard and CircularGallery from @DavidHDev/react-bits
- 🖼️ Mock data for quick prototyping

## Quick Start

### 1. Install dependencies

```bash
npm install
# or
yarn install
```

### 2. Run the development server

```bash
npm run dev
# or
yarn dev
```

Open [http://localhost:5173](http://localhost:5173) (or as printed in terminal).

### 3. Build for production

```bash
npm run build
```

## How it works

- The `ProfileCard` displays a demo user.
- The `CircularGallery` shows a set of “emotion” icons with labels.

You can replace the data in `src/App.tsx` with your own.

## Customization

- Change the profile data in `src/App.tsx`
- Replace the `emotionGallery` array with your own images and labels

## Learn more

- [react-bits components docs](https://www.reactbits.dev/components)
- [Vite documentation](https://vitejs.dev/guide/)

---

Made with ❤️ using [@DavidHDev/react-bits](https://www.reactbits.dev/)