import React from "react";
import { ProfileCard, CircularGallery } from "@DavidHDev/react-bits";
import "./App.css";

// Demo data for the ProfileCard
const profile = {
  name: "Jane Doe",
  title: "Frontend Developer",
  avatar: "https://randomuser.me/api/portraits/women/44.jpg",
  description: "Building beautiful UIs with React and Bits.",
  socials: [
    { icon: "github", url: "https://github.com/janedoe" },
    { icon: "twitter", url: "https://twitter.com/janedoe" }
  ]
};

// Demo data for CircularGallery, representing emotions
const emotionGallery = [
  {
    image: "https://cdn-icons-png.flaticon.com/512/742/742751.png",
    label: "Happy"
  },
  {
    image: "https://cdn-icons-png.flaticon.com/512/742/742752.png",
    label: "Sad"
  },
  {
    image: "https://cdn-icons-png.flaticon.com/512/742/742753.png",
    label: "Excited"
  },
  {
    image: "https://cdn-icons-png.flaticon.com/512/742/742754.png",
    label: "Calm"
  }
];

export default function App() {
  return (
    <div className="container">
      <ProfileCard {...profile} />
      <h2 className="gallery-title">Emotions</h2>
      <CircularGallery items={emotionGallery} />
    </div>
  );
}